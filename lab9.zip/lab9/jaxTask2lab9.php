<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AjaxTask2</title>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">

    function addCombo() {
    var textb = document.getElementById("txtCombo");
    var combo = document.getElementById("combo");
    
    var option = document.createElement("option");
    option.text = textb.value;
    option.value = textb.value;
    try {
        combo.add(option, null); //Standard 
    }catch(error) {
        combo.add(option); // IE only
    }
    textb.value = "";
}

$(document).ready(function(){
    $("select.country").change(function(){
        var selectedCountry = $(".country option:selected").val();
        $.ajax({
            type: "POST",
            url: "Task2.php",
            data: { country : selectedCountry } 
        }).done(function(data){
            $("#r").html(data);
        });
    });
});

</script>

<style type="text/css">
    
div{
width:  500px;
   position: absolute;
   top: 50%;
   bottom: 50%;
   left: 50%;
   right: 50%;
}
#txtCombo{
    width: 500px;
    height: 30px;
    background-color:   #C0C0C0;
}
#b{
   width: 200px;
    height: 50px;
    background-color:   green; 
}
c
#country{
      width: 200px;
    height: 30px;
    background-color:   #C0C0C0;
}
</style>
</head>
<body>
<div>
<form>
    <table>
        <tr>
            <td>
                <label>Enter a city Name</label>
            <input type="text" name="txtCombo" id="txtCombo"/>
            <input id="b" type="button" value="Add to ComboBox" onclick="addCombo()">
            <br/><br/>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            Country:<select  name="combo" id="combo" class="country"></select>
            </td>
            <td id="r">
                <!--Response will be inserted here-->
            </td>
        </tr>
    </table>
</form>
</div>
</body> 
</html>