<!DOCTYPE html>
<html>
<head>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  
<meta name="viewport" content="width=device-width, initial-scale=1">

<script >
  $(document).ready(function(){
    $("#sub").click(function(){

      var $fname=$("#fname").val();
      var $lname=$("#lname").val();
      var $te=$("#te").val();
     alert("Data insert successfully"."<br>".$fname." ".$lname);
      $.ajax({
        url:"postform.php",
        type:"post",
        data:{fname:fname,lname:lname,te:te},
        success:function(data){
          $("#name").val("");
          $("#email").val("");
          $("#roll").val("");
        
       
          alert("data successfully send ");
        }

      });
    });


  });
</script>
<style>


body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select  {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;

}

#te{
  width: 1770px;
  height: 45px;
}
</style>
</head>
<body>

<h3>Contact Form</h3>

<div class="container">
  <form  action="postform.php" method="post">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="fname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lname" placeholder="Your last name..">

    <label for="country">Phone number</label><br>
    <input id="te" type="tel" name="te" placeholder="Enter phone number"><br><br>

  
  

    <input id="sub" type="submit" value="Submit">
  </form>
</div>

</body>
</html>
