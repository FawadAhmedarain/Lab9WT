<?php
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$te=$_POST['te'];

print "Welcom ".$fname."  ".$lname."<br>";
print "Your Phone number: ".$te;
?>