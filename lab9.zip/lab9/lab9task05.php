<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $('#Button').on("click",function() {
         $("#ul").css("display","block");
    });
  });
</script>
<style type="text/css">
	
	#ul{
		display: none;

	}
	#u{
		list-style-type: square;
	}
</style>
</head>
<body>
	<Button name="Button" id="Button"> Click here to see a list</Button><br><br>
<div id = "ul">
<ul id="u">
	<li>16SW01</li>
	<li>16SW13</li>
	<li>16SW35</li>
	<li>16SW57</li>
	<li>16SW161</li>
	<li>16SW173</li>
</ul>
</div>
</body>
</html>