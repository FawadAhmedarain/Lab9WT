$(document).ready(function(v){
	$("#hh1").click(function (e){

	$("#hh1").hide();	
	

	
	});
	$("#hh2").click(function (e){

	$("#hh2").hide();	
	

	
	});
	$("#hh3").click(function (e){

	$("#hh3").hide();	
	

	
	});
	$("#hh4").click(function (e){

	$("#hh4").hide();	
	

	
	});
	$("#hh5").click(function (e){

	$("#hh5").hide();	
	

	
	});

$("#hh6").click(function (e){

	$("#hh6").hide();	
	

	
	});

});