$(document).ready(function(){
  $("#t1").focus(function(){
    $("#s1").css("display", "inline").fadeOut(2000);
  });

  $("#t2").focus(function(){
    $("#s2").css("display", "inline").fadeOut(2000);
  });
  $("#t3").focus(function(){
    $("#s3").css("display", "inline").fadeOut(2000);
  });
});
