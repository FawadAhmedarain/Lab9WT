
$(document).ready(function(){

    $("p").dblclick(
    
    function(){$("p").css({"color": "red"});
  });
});

